import axios from "axios";

export const getCharacterById = async (id) => {
  const data = await axios.get(
    "https://rickandmortyapi.com/api/character/" + id
  );
  return data.data;
};
