import { useEffect, useState } from "react";
import { getCharacterById } from "./services/api";

const App = () => {
  const [character, setCharacter] = useState([]);
  const [characterNumber, setCharacterNumber] = useState(1);

  useEffect(() => {
    getCharacterById(characterNumber).then(setCharacter);
  }, [characterNumber]);

  return (
    <div>
      <input type="text" onChange={(e) => setCharacterNumber(e.target.value)} />
      <h1>{character.name}</h1>
      <img src={character.image} alt={character.name} />
    </div>
  );
};

export default App;
